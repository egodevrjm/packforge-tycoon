import type { TycoonGamePack } from "@packforge/core";

export const festivalPack: TycoonGamePack = {
  id: "festival",
  theme: {
    title: "Festival Tycoon",
    subtitle: "Build a tiny local gig into a must-play weekend festival.",
    description:
      "An event management pack about artists, stages, vendors, logistics, hype, tickets, and reputation.",
    visual: {
      icon: "audio",
      illustration: "festival",
      sceneImage: "/assets/key-art/pack-grid-ai.png",
      logoImage: "/assets/key-art/pack-grid-ai.png"
    },
    palette: {
      soil: "#1f2937",
      grid: "#a5b4fc",
      accent: "#7c3aed",
      panel: "#ffffff"
    },
    ui: {
      background: "#f7f4ff",
      surface: "#ffffff",
      surfaceAlt: "#f1eaff",
      text: "#111827",
      muted: "#6b7280",
      border: "#ddd6fe",
      accent: "#7c3aed",
      accentStrong: "#5b21b6",
      accentSoft: "#ede9fe",
      success: "#16a34a",
      warning: "#f97316",
      danger: "#dc2626"
    }
  },
  resources: [
    { id: "artists", name: "Artists", description: "Booked performers and creative partners." },
    { id: "stages", name: "Stages", description: "Performance capacity ready for the lineup." },
    { id: "sound", name: "Sound", description: "Audio equipment, tech checks, and loud competence." },
    { id: "vendors", name: "Vendors", description: "Food, drinks, merch, and useful queues." },
    { id: "hype", name: "Hype", description: "Local chatter and social attention." },
    { id: "tickets", name: "Tickets", description: "Sold passes and committed audience demand." },
    { id: "logistics", name: "Logistics", description: "Permits, power, fencing, toilets, and the unglamorous truth." },
    { id: "reputation", name: "Reputation", description: "Proof that the event is worth coming back for." }
  ],
  recipes: [
    { id: "book_artists", name: "Book Artists", durationMs: 2200, inputs: {}, outputs: { artists: 3 } },
    { id: "build_stage", name: "Build Stage", durationMs: 3000, inputs: { logistics: 1 }, outputs: { stages: 2 } },
    { id: "sound_check", name: "Sound Check", durationMs: 2800, inputs: { stages: 1 }, outputs: { sound: 3 } },
    { id: "vendor_outreach", name: "Vendor Outreach", durationMs: 2600, inputs: {}, outputs: { vendors: 3 } },
    { id: "permit_run", name: "Permit Run", durationMs: 2400, inputs: {}, outputs: { logistics: 3 } },
    { id: "poster_campaign", name: "Poster Campaign", durationMs: 3200, inputs: { artists: 1 }, outputs: { hype: 4 } },
    { id: "ticket_push", name: "Ticket Push", durationMs: 4200, inputs: { hype: 3, sound: 1 }, outputs: { tickets: 3 } },
    { id: "run_show", name: "Run Show", durationMs: 5200, inputs: { artists: 2, stages: 1, sound: 2, vendors: 1 }, outputs: { reputation: 2, tickets: 2 } }
  ],
  buildings: [
    {
      id: "artist_roster",
      name: "Artist Roster",
      description: "A folding table, a phone, and enough taste to book a lineup.",
      category: "booking",
      size: { width: 1, height: 1 },
      cost: 0,
      recipeId: "book_artists",
      color: "#ec4899",
      icon: "audio"
    },
    {
      id: "permit_clipboard",
      name: "Permit Clipboard",
      description: "Keeps the festival legally boring, which is secretly excellent.",
      category: "logistics",
      size: { width: 1, height: 1 },
      cost: 45,
      recipeId: "permit_run",
      color: "#64748b",
      icon: "clipboard"
    },
    {
      id: "community_stage",
      name: "Community Stage",
      description: "A starter stage that makes the event real.",
      category: "production",
      size: { width: 2, height: 1 },
      cost: 80,
      recipeId: "build_stage",
      color: "#7c3aed",
      icon: "station"
    },
    {
      id: "sound_tent",
      name: "Sound Tent",
      description: "Turns planks and cables into something people can actually hear.",
      category: "production",
      size: { width: 2, height: 1 },
      cost: 110,
      recipeId: "sound_check",
      color: "#2563eb",
      icon: "audio"
    },
    {
      id: "vendor_lane",
      name: "Vendor Lane",
      description: "Adds food, merch, and reasons for guests to stay longer.",
      category: "vendors",
      size: { width: 2, height: 1 },
      cost: 120,
      recipeId: "vendor_outreach",
      color: "#f59e0b",
      icon: "package"
    },
    {
      id: "poster_wall",
      name: "Poster Wall",
      description: "Old-school promotion that still works when the art is good.",
      category: "marketing",
      size: { width: 1, height: 1 },
      cost: 95,
      recipeId: "poster_campaign",
      color: "#06b6d4",
      icon: "megaphone"
    },
    {
      id: "ticket_booth",
      name: "Ticket Booth",
      description: "Converts attention into actual attendance.",
      category: "sales",
      size: { width: 2, height: 1 },
      cost: 170,
      recipeId: "ticket_push",
      color: "#22c55e",
      icon: "coin"
    },
    {
      id: "main_stage_ops",
      name: "Main Stage Ops",
      description: "Coordinates the show people will talk about afterwards.",
      category: "operations",
      size: { width: 3, height: 2 },
      cost: 320,
      recipeId: "run_show",
      color: "#ef4444",
      icon: "rocket"
    }
  ],
  contracts: [
    {
      id: "first_lineup",
      name: "First Lineup",
      description: "Book enough artists to make the poster worth printing.",
      requires: { artists: 8 },
      rewardCash: 130,
      unlockIds: ["community_stage", "sound_tent", "sound_ready"]
    },
    {
      id: "sound_ready",
      name: "Sound Ready",
      description: "Get the stage and sound together for a proper local show.",
      requires: { stages: 6, sound: 8 },
      rewardCash: 220,
      unlockIds: ["vendor_lane", "poster_wall", "poster_blast"]
    },
    {
      id: "poster_blast",
      name: "Poster Blast",
      description: "Create enough hype that people start asking about tickets.",
      requires: { hype: 12 },
      rewardCash: 260,
      unlockIds: ["ticket_booth", "early_bird"]
    },
    {
      id: "early_bird",
      name: "Early Bird Tickets",
      description: "Turn hype into committed audience before costs get scary.",
      requires: { tickets: 10 },
      rewardCash: 380,
      unlockIds: ["main_stage_ops", "vendor_sponsor"]
    },
    {
      id: "vendor_sponsor",
      name: "Vendor Sponsor Row",
      description: "Bundle artists, vendors, and audience proof into a sponsor pitch.",
      requires: { vendors: 10, tickets: 8, hype: 8 },
      rewardCash: 520,
      unlockIds: ["festival_expansion", "headline_weekend"]
    },
    {
      id: "headline_weekend",
      name: "Headline Weekend",
      description: "A repeatable mature festival weekend with a proper crowd.",
      requires: { reputation: 8, tickets: 14, logistics: 10 },
      rewardCash: 820,
      unlockIds: [],
      repeatable: true
    }
  ],
  upgrades: [
    {
      id: "booking_network",
      name: "Booking Network",
      description: "Booking work is 30% faster.",
      cost: 180,
      effect: { productionMultipliers: [{ category: "booking", multiplier: 1.3 }] }
    },
    {
      id: "stage_rigging",
      name: "Stage Rigging",
      description: "Production stations build output faster.",
      cost: 260,
      effect: { productionMultipliers: [{ category: "production", multiplier: 1.25 }] }
    },
    {
      id: "street_team",
      name: "Street Team",
      description: "Marketing creates hype faster.",
      cost: 300,
      effect: { productionMultipliers: [{ category: "marketing", multiplier: 1.35 }] }
    },
    {
      id: "box_office_flow",
      name: "Box Office Flow",
      description: "Sales stations convert hype into tickets faster.",
      cost: 380,
      effect: { productionMultipliers: [{ category: "sales", multiplier: 1.3 }] }
    },
    {
      id: "festival_expansion",
      name: "Open the Second Field",
      description: "Expand the festival grounds for bigger operations.",
      cost: 680,
      effect: { expandGrid: { width: 4, height: 2 } }
    }
  ],
  actions: [
    {
      id: "local_radio_spot",
      name: "Local Radio Spot",
      description: "Spend cash to create a burst of hype.",
      costCash: 50,
      cooldownMs: 22_000,
      effect: { resources: { hype: 8 } },
      icon: "megaphone"
    },
    {
      id: "artist_takeover",
      name: "Artist Takeover",
      description: "Use artists and hype to sell a batch of tickets.",
      costCash: 65,
      costResources: { artists: 2, hype: 2 },
      cooldownMs: 30_000,
      effect: { resources: { tickets: 5 } },
      icon: "audio"
    },
    {
      id: "volunteer_push",
      name: "Volunteer Push",
      description: "Double logistics output during a short operations sprint.",
      costCash: 90,
      costResources: { hype: 4 },
      cooldownMs: 40_000,
      effect: { productionBoost: { category: "logistics", multiplier: 2, durationMs: 18_000 } },
      icon: "workers"
    }
  ],
  markets: [
    {
      id: "local-crowd",
      name: "Local Crowd",
      description: "Affordable shows with familiar artists and low friction.",
      demand: 1.18,
      rewardMultiplier: 1.08,
      qualityMultiplier: 1
    },
    {
      id: "destination-fans",
      name: "Destination Fans",
      description: "Traveling fans who reward strong lineups, logistics, and reputation.",
      demand: 0.86,
      rewardMultiplier: 1.24,
      qualityMultiplier: 1.28
    }
  ],
  projects: [
    {
      id: "first_showcase",
      name: "First Showcase",
      description: "Run a compact local showcase and prove the festival can work.",
      marketId: "local-crowd",
      rewardCash: 300,
      unlockIds: ["poster_blast", "local_radio_spot"],
      phases: [
        { id: "booking", name: "Book", durationMs: 4_000, qualityFromResources: { artists: 2 }, risk: 1 },
        { id: "production", name: "Stage", durationMs: 5_000, qualityFromResources: { stages: 2, sound: 2 }, risk: 2 },
        { id: "marketing", name: "Promote", durationMs: 5_000, qualityFromResources: { hype: 2 }, risk: 1 },
        { id: "operations", name: "Run Show", durationMs: 6_000, qualityFromResources: { reputation: 2 }, risk: 3 }
      ]
    },
    {
      id: "weekend_festival",
      name: "Weekend Festival",
      description: "Build the first full weekend with sponsors, ticketing, and a real crowd.",
      marketId: "destination-fans",
      costCash: 180,
      requiredResources: { tickets: 2 },
      rewardCash: 700,
      unlockIds: ["headline_weekend"],
      phases: [
        { id: "booking", name: "Lineup", durationMs: 6_000, qualityFromResources: { artists: 3 }, risk: 2 },
        { id: "logistics", name: "Site", durationMs: 6_000, qualityFromResources: { logistics: 3 }, risk: 2 },
        { id: "sales", name: "Tickets", durationMs: 5_000, qualityFromResources: { tickets: 3, hype: 2 }, risk: 1 },
        { id: "operations", name: "Weekend", durationMs: 7_000, qualityFromResources: { reputation: 3, vendors: 2 }, risk: 2 }
      ]
    }
  ],
  events: [
    {
      id: "weather-watch",
      name: "Weather Watch",
      description: "The forecast turns uncertain just as the schedule locks.",
      trigger: { elapsedMs: 30_000 },
      choices: [
        {
          id: "rent-cover",
          label: "Rent Cover",
          description: "Spend logistics to lower risk.",
          effect: { resources: { logistics: -2 }, projectRisk: -5, projectQuality: 1 }
        },
        {
          id: "keep-budget",
          label: "Keep Budget",
          description: "Save cash, but the show becomes riskier.",
          effect: { cash: 40, projectRisk: 7 }
        }
      ]
    },
    {
      id: "surprise-act",
      name: "Surprise Act",
      description: "A beloved local artist offers to play if you can fit them in.",
      trigger: { unlockedId: "ticket_booth" },
      choices: [
        {
          id: "add-slot",
          label: "Add Slot",
          description: "Boost hype and quality at an operations cost.",
          effect: { resources: { artists: 2, hype: 5 }, projectQuality: 4, projectRisk: 2 }
        },
        {
          id: "protect-schedule",
          label: "Protect Schedule",
          description: "Keep the plan clean and lower risk.",
          effect: { projectRisk: -3, morale: 2 }
        }
      ]
    }
  ],
  staffRoles: [
    { id: "booker", name: "Booker", category: "booking", baseWage: 0.15 },
    { id: "stage-tech", name: "Stage Tech", category: "production", baseWage: 0.17 },
    { id: "site-manager", name: "Site Manager", category: "logistics", baseWage: 0.18 },
    { id: "promoter", name: "Promoter", category: "marketing", baseWage: 0.15 },
    { id: "box-office-lead", name: "Box Office Lead", category: "sales", baseWage: 0.16 },
    { id: "ops-producer", name: "Ops Producer", category: "operations", baseWage: 0.2 }
  ],
  staffCandidates: [
    { id: "candidate-rhea", name: "Rhea Moon", roleId: "booker", hireCost: 155, level: 1, traits: ["taste", "networked"], morale: 78 },
    { id: "candidate-joss", name: "Joss Lane", roleId: "stage-tech", hireCost: 185, level: 2, traits: ["calm", "technical"], morale: 76 },
    { id: "candidate-amal", name: "Amal Cross", roleId: "site-manager", hireCost: 210, level: 2, traits: ["organized", "direct"], morale: 74 }
  ],
  startingState: {
    grid: { width: 8, height: 6 },
    cash: 280,
    resources: {
      artists: 0,
      stages: 0,
      sound: 0,
      vendors: 0,
      hype: 0,
      tickets: 0,
      logistics: 6,
      reputation: 0
    },
    unlockedIds: ["artist_roster", "permit_clipboard", "community_stage", "first_lineup", "first_showcase"]
  }
};
