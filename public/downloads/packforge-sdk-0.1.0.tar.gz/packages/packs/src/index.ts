import { createGamePackage, type PackForgeGamePackage, type TycoonGamePack } from "@packforge/core";
import { boutiqueHotelPack } from "./boutique-hotel";
import { coffeeShopPack } from "./coffee-shop";
import { festivalPack } from "./festival";
import { gameStudioPack } from "./game-studio";
import { scrapyardPack } from "./scrapyard";
import { spaceColonyPack } from "./space-colony";

export interface RegisteredGamePack {
  pack: TycoonGamePack;
  tagline: string;
}

export const sampleGamePackage: PackForgeGamePackage = createGamePackage(
  {
    packageId: "packforge.samples",
    displayName: "PackForge Sample Games",
    version: "0.1.0",
    description: "Starter management tycoon game packs for PackForge.",
    author: "PackForge",
    tags: ["sample", "management", "tycoon"],
    entryPackId: gameStudioPack.id
  },
  [gameStudioPack, scrapyardPack, coffeeShopPack, spaceColonyPack, boutiqueHotelPack, festivalPack]
);

export const gamePackages: PackForgeGamePackage[] = [sampleGamePackage];

const packTagline = (packId: string) =>
  ({
    "game-studio": "Game Dev Tycoon style: ideas, builds, fans, contracts, and studio departments.",
    scrapyard: "Industrial management: stations, staff, contracts, and reclaimed materials.",
    "coffee-shop": "Cozy service tycoon: beans, drinks, pastries, local buzz, and regulars.",
    "space-colony": "Frontier infrastructure: power, water, oxygen, crops, research, and morale.",
    "boutique-hotel": "Hospitality management: rooms, service, comfort, events, reviews, and loyalty.",
    festival: "Event management: artists, stages, logistics, hype, tickets, and reputation."
  })[packId] ?? "A PackForge management tycoon game.";

export const gamePacks: RegisteredGamePack[] = sampleGamePackage.packs.map((pack) => ({
  pack,
  tagline: packTagline(pack.id)
}));

export const gamePackEntries: RegisteredGamePack[] = [
  {
    pack: gameStudioPack,
    tagline: packTagline(gameStudioPack.id)
  },
  {
    pack: scrapyardPack,
    tagline: packTagline(scrapyardPack.id)
  },
  {
    pack: coffeeShopPack,
    tagline: packTagline(coffeeShopPack.id)
  },
  {
    pack: spaceColonyPack,
    tagline: packTagline(spaceColonyPack.id)
  },
  {
    pack: boutiqueHotelPack,
    tagline: packTagline(boutiqueHotelPack.id)
  },
  {
    pack: festivalPack,
    tagline: packTagline(festivalPack.id)
  }
];

export const defaultGamePackId = gameStudioPack.id;

export const getGamePack = (packId: string) =>
  gamePacks.find((entry) => entry.pack.id === packId)?.pack ?? gameStudioPack;

export const getGamePackage = (packageId: string) =>
  gamePackages.find((entry) => entry.manifest.packageId === packageId) ?? sampleGamePackage;

export { boutiqueHotelPack, coffeeShopPack, festivalPack, gameStudioPack, scrapyardPack, spaceColonyPack };
