import type { TycoonGamePack } from "./types";

export interface ValidationResult {
  ok: boolean;
  errors: string[];
}

const collectDuplicateIds = (kind: string, ids: string[]) => {
  const seen = new Set<string>();
  const duplicates = new Set<string>();
  for (const id of ids) {
    if (seen.has(id)) {
      duplicates.add(id);
    }
    seen.add(id);
  }
  return [...duplicates].map((id) => `${kind} id "${id}" is duplicated.`);
};

export const validateGamePack = (pack: TycoonGamePack): ValidationResult => {
  const errors: string[] = [];
  const resourceIds = new Set(pack.resources.map((resource) => resource.id));
  const recipeIds = new Set(pack.recipes.map((recipe) => recipe.id));
  const buildingIds = new Set(pack.buildings.map((building) => building.id));
  const contractIds = new Set(pack.contracts.map((contract) => contract.id));
  const upgradeIds = new Set(pack.upgrades.map((upgrade) => upgrade.id));
  const actionIds = new Set((pack.actions ?? []).map((action) => action.id));
  const projectIds = new Set((pack.projects ?? []).map((project) => project.id));
  const marketIds = new Set((pack.markets ?? []).map((market) => market.id));
  const eventIds = new Set((pack.events ?? []).map((event) => event.id));
  const staffRoleIds = new Set((pack.staffRoles ?? []).map((role) => role.id));
  const categories = new Set(pack.buildings.map((building) => building.category));
  const allUnlockableIds = new Set([
    ...buildingIds,
    ...contractIds,
    ...upgradeIds,
    ...actionIds,
    ...projectIds,
    ...resourceIds
  ]);

  errors.push(
    ...collectDuplicateIds("Resource", pack.resources.map((resource) => resource.id)),
    ...collectDuplicateIds("Recipe", pack.recipes.map((recipe) => recipe.id)),
    ...collectDuplicateIds("Building", pack.buildings.map((building) => building.id)),
    ...collectDuplicateIds("Contract", pack.contracts.map((contract) => contract.id)),
    ...collectDuplicateIds("Upgrade", pack.upgrades.map((upgrade) => upgrade.id)),
    ...collectDuplicateIds("Action", (pack.actions ?? []).map((action) => action.id)),
    ...collectDuplicateIds("Project", (pack.projects ?? []).map((project) => project.id)),
    ...collectDuplicateIds("Market", (pack.markets ?? []).map((market) => market.id)),
    ...collectDuplicateIds("Event", (pack.events ?? []).map((event) => event.id)),
    ...collectDuplicateIds("Staff role", (pack.staffRoles ?? []).map((role) => role.id)),
    ...collectDuplicateIds("Staff candidate", (pack.staffCandidates ?? []).map((candidate) => candidate.id))
  );

  for (const recipe of pack.recipes) {
    for (const resourceId of [...Object.keys(recipe.inputs), ...Object.keys(recipe.outputs)]) {
      if (!resourceIds.has(resourceId)) {
        errors.push(`Recipe "${recipe.id}" references unknown resource "${resourceId}".`);
      }
    }
    if (recipe.durationMs <= 0) {
      errors.push(`Recipe "${recipe.id}" must have a positive duration.`);
    }
  }

  for (const building of pack.buildings) {
    if (building.recipeId && !recipeIds.has(building.recipeId)) {
      errors.push(`Building "${building.id}" references unknown recipe "${building.recipeId}".`);
    }
    if (building.size.width <= 0 || building.size.height <= 0) {
      errors.push(`Building "${building.id}" must have a positive size.`);
    }
  }

  for (const contract of pack.contracts) {
    for (const resourceId of Object.keys(contract.requires)) {
      if (!resourceIds.has(resourceId)) {
        errors.push(`Contract "${contract.id}" requires unknown resource "${resourceId}".`);
      }
    }
    for (const unlockId of contract.unlockIds) {
      if (!allUnlockableIds.has(unlockId)) {
        errors.push(`Contract "${contract.id}" unlocks unknown id "${unlockId}".`);
      }
    }
  }

  for (const upgrade of pack.upgrades) {
    for (const unlockId of upgrade.effect.unlockIds ?? []) {
      if (!allUnlockableIds.has(unlockId)) {
        errors.push(`Upgrade "${upgrade.id}" unlocks unknown id "${unlockId}".`);
      }
    }
  }

  for (const action of pack.actions ?? []) {
    if (action.cooldownMs < 0) {
      errors.push(`Action "${action.id}" must not have a negative cooldown.`);
    }
    for (const unlockId of action.unlockIds ?? []) {
      if (!allUnlockableIds.has(unlockId)) {
        errors.push(`Action "${action.id}" unlocks unknown id "${unlockId}".`);
      }
    }
    for (const resourceId of [
      ...Object.keys(action.costResources ?? {}),
      ...Object.keys(action.effect.resources ?? {})
    ]) {
      if (!resourceIds.has(resourceId)) {
        errors.push(`Action "${action.id}" references unknown resource "${resourceId}".`);
      }
    }
    const boostCategory = action.effect.productionBoost?.category;
    if (boostCategory && !pack.buildings.some((building) => building.category === boostCategory)) {
      errors.push(`Action "${action.id}" boosts unknown category "${boostCategory}".`);
    }
  }

  for (const market of pack.markets ?? []) {
    if (market.demand <= 0) {
      errors.push(`Market "${market.id}" must have positive demand.`);
    }
  }

  for (const project of pack.projects ?? []) {
    if (project.phases.length === 0) {
      errors.push(`Project "${project.id}" must include at least one phase.`);
    }
    if (project.marketId && !marketIds.has(project.marketId)) {
      errors.push(`Project "${project.id}" references unknown market "${project.marketId}".`);
    }
    for (const resourceId of Object.keys(project.requiredResources ?? {})) {
      if (!resourceIds.has(resourceId)) {
        errors.push(`Project "${project.id}" requires unknown resource "${resourceId}".`);
      }
    }
    for (const unlockId of project.unlockIds ?? []) {
      if (!allUnlockableIds.has(unlockId)) {
        errors.push(`Project "${project.id}" unlocks unknown id "${unlockId}".`);
      }
    }
    for (const phase of project.phases) {
      if (phase.durationMs <= 0) {
        errors.push(`Project "${project.id}" phase "${phase.id}" must have a positive duration.`);
      }
      for (const resourceId of Object.keys(phase.qualityFromResources ?? {})) {
        if (!resourceIds.has(resourceId)) {
          errors.push(`Project "${project.id}" phase "${phase.id}" references unknown resource "${resourceId}".`);
        }
      }
    }
  }

  for (const event of pack.events ?? []) {
    if (event.choices.length === 0) {
      errors.push(`Event "${event.id}" must include at least one choice.`);
    }
    if (event.trigger.unlockedId && !allUnlockableIds.has(event.trigger.unlockedId)) {
      errors.push(`Event "${event.id}" listens for unknown unlock "${event.trigger.unlockedId}".`);
    }
    for (const choice of event.choices) {
      for (const resourceId of Object.keys(choice.effect.resources ?? {})) {
        if (!resourceIds.has(resourceId)) {
          errors.push(`Event "${event.id}" choice "${choice.id}" references unknown resource "${resourceId}".`);
        }
      }
      for (const unlockId of choice.effect.unlockIds ?? []) {
        if (!allUnlockableIds.has(unlockId)) {
          errors.push(`Event "${event.id}" choice "${choice.id}" unlocks unknown id "${unlockId}".`);
        }
      }
    }
  }

  for (const role of pack.staffRoles ?? []) {
    if (!categories.has(role.category)) {
      errors.push(`Staff role "${role.id}" references unknown category "${role.category}".`);
    }
    if (role.baseWage < 0) {
      errors.push(`Staff role "${role.id}" must not have a negative wage.`);
    }
  }

  for (const candidate of pack.staffCandidates ?? []) {
    if (!staffRoleIds.has(candidate.roleId)) {
      errors.push(`Staff candidate "${candidate.id}" references unknown role "${candidate.roleId}".`);
    }
    if (candidate.hireCost < 0) {
      errors.push(`Staff candidate "${candidate.id}" must not have a negative hire cost.`);
    }
    if (candidate.level <= 0) {
      errors.push(`Staff candidate "${candidate.id}" must have a positive level.`);
    }
  }

  for (const resourceId of Object.keys(pack.startingState.resources)) {
    if (!resourceIds.has(resourceId)) {
      errors.push(`Starting state references unknown resource "${resourceId}".`);
    }
  }

  for (const unlockId of pack.startingState.unlockedIds) {
    if (!allUnlockableIds.has(unlockId)) {
      errors.push(`Starting state unlocks unknown id "${unlockId}".`);
    }
  }

  const reachableResources = new Set(Object.keys(pack.startingState.resources));
  for (const action of pack.actions ?? []) {
    for (const resourceId of Object.keys(action.effect.resources ?? {})) {
      reachableResources.add(resourceId);
    }
  }
  let changed = true;
  while (changed) {
    changed = false;
    for (const recipe of pack.recipes) {
      const canProduce = Object.keys(recipe.inputs).every((resourceId) => reachableResources.has(resourceId));
      if (!canProduce) {
        continue;
      }
      for (const resourceId of Object.keys(recipe.outputs)) {
        if (!reachableResources.has(resourceId)) {
          reachableResources.add(resourceId);
          changed = true;
        }
      }
    }
  }
  for (const contract of pack.contracts) {
    for (const resourceId of Object.keys(contract.requires)) {
      if (resourceIds.has(resourceId) && !reachableResources.has(resourceId)) {
        errors.push(`Contract "${contract.id}" requires unreachable resource "${resourceId}".`);
      }
    }
  }

  return {
    ok: errors.length === 0,
    errors
  };
};
